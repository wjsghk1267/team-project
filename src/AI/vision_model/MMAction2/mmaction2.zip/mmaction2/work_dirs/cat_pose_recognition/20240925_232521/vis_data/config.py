ann_file_test = 'G:/workspace/test/mmaction2_data/annotations/cat_pose.txt'
ann_file_train = 'G:/workspace/test/mmaction2_data/annotations/cat_pose.txt'
ann_file_val = 'G:/workspace/test/mmaction2_data/annotations/cat_pose.txt'
data_root = 'G:/workspace/test/mmaction2_data'
dataset_type = 'CatPoseDataset'
default_hooks = dict(
    checkpoint=dict(interval=5, type='CheckpointHook'),
    logger=dict(interval=20, type='LoggerHook'),
    param_scheduler=dict(type='ParamSchedulerHook'),
    sampler_seed=dict(type='DistSamplerSeedHook'),
    timer=dict(type='IterTimerHook'),
    visualization=dict(type='ActionVisualizationHook'))
default_scope = 'mmaction'
img_norm_cfg = dict(
    mean=[
        123.675,
        116.28,
        103.53,
    ],
    std=[
        58.395,
        57.12,
        57.375,
    ],
    to_bgr=False)
launcher = 'none'
model = dict(
    backbone=dict(
        depth=50,
        in_channels=3,
        norm_eval=False,
        out_indices=(
            2,
            3,
        ),
        type='ResNet'),
    cls_head=dict(
        consensus=dict(dim=1, type='AvgConsensus'),
        dropout_ratio=0.4,
        in_channels=2048,
        init_std=0.01,
        num_classes=2,
        spatial_type='avg',
        type='TSNHead'),
    type='Recognizer2D')
optim_wrapper = dict(
    clip_grad=dict(max_norm=40, norm_type=2),
    optimizer=dict(lr=0.01, momentum=0.9, type='SGD', weight_decay=0.0001))
param_scheduler = [
    dict(
        begin=0,
        by_epoch=True,
        end=100,
        gamma=0.1,
        milestones=[
            40,
            80,
        ],
        type='MultiStepLR'),
]
randomness = dict(deterministic=False, diff_rank_seed=False, seed=None)
test_cfg = dict(type='TestLoop')
test_dataloader = dict(
    batch_size=1,
    dataset=dict(
        ann_file='G:/workspace/test/mmaction2_data/annotations/cat_pose.txt',
        data_prefix=dict(img='G:/workspace/test/mmaction2_data/rawframes'),
        pipeline=[
            dict(
                clip_len=1,
                frame_interval=1,
                num_clips=8,
                test_mode=True,
                type='SampleFrames'),
            dict(type='RawFrameDecode'),
            dict(scale=(
                -1,
                256,
            ), type='Resize'),
            dict(crop_size=224, type='CenterCrop'),
            dict(flip_ratio=0, type='Flip'),
            dict(
                mean=[
                    123.675,
                    116.28,
                    103.53,
                ],
                std=[
                    58.395,
                    57.12,
                    57.375,
                ],
                to_bgr=False,
                type='Normalize'),
            dict(input_format='NCHW', type='FormatShape'),
            dict(
                keys=[
                    'imgs',
                    'label',
                    'metadata',
                    'keypoints',
                ],
                meta_keys=[],
                type='Collect'),
            dict(keys=[
                'imgs',
                'metadata',
                'keypoints',
            ], type='ToTensor'),
        ],
        type='CatPoseDataset'),
    num_workers=2,
    persistent_workers=True,
    sampler=dict(shuffle=False, type='DefaultSampler'))
test_evaluator = dict(type='AccMetric')
test_pipeline = [
    dict(
        clip_len=1,
        frame_interval=1,
        num_clips=8,
        test_mode=True,
        type='SampleFrames'),
    dict(type='RawFrameDecode'),
    dict(scale=(
        -1,
        256,
    ), type='Resize'),
    dict(crop_size=224, type='CenterCrop'),
    dict(flip_ratio=0, type='Flip'),
    dict(
        mean=[
            123.675,
            116.28,
            103.53,
        ],
        std=[
            58.395,
            57.12,
            57.375,
        ],
        to_bgr=False,
        type='Normalize'),
    dict(input_format='NCHW', type='FormatShape'),
    dict(
        keys=[
            'imgs',
            'label',
            'metadata',
            'keypoints',
        ],
        meta_keys=[],
        type='Collect'),
    dict(keys=[
        'imgs',
        'metadata',
        'keypoints',
    ], type='ToTensor'),
]
train_cfg = dict(
    max_epochs=100, type='EpochBasedTrainLoop', val_begin=1, val_interval=1)
train_dataloader = dict(
    batch_size=8,
    dataset=dict(
        ann_file='G:/workspace/test/mmaction2_data/annotations/cat_pose.txt',
        data_prefix=dict(img='G:/workspace/test/mmaction2_data/rawframes'),
        pipeline=[
            dict(
                clip_len=1, frame_interval=1, num_clips=8,
                type='SampleFrames'),
            dict(type='RawFrameDecode'),
            dict(scale=(
                -1,
                256,
            ), type='Resize'),
            dict(type='RandomResizedCrop'),
            dict(keep_ratio=False, scale=(
                224,
                224,
            ), type='Resize'),
            dict(flip_ratio=0.5, type='Flip'),
            dict(
                mean=[
                    123.675,
                    116.28,
                    103.53,
                ],
                std=[
                    58.395,
                    57.12,
                    57.375,
                ],
                to_bgr=False,
                type='Normalize'),
            dict(input_format='NCHW', type='FormatShape'),
            dict(
                keys=[
                    'imgs',
                    'label',
                    'metadata',
                    'keypoints',
                ],
                meta_keys=[],
                type='Collect'),
            dict(
                keys=[
                    'imgs',
                    'label',
                    'metadata',
                    'keypoints',
                ],
                type='ToTensor'),
        ],
        type='CatPoseDataset'),
    num_workers=2,
    persistent_workers=True,
    sampler=dict(shuffle=True, type='DefaultSampler'))
train_pipeline = [
    dict(clip_len=1, frame_interval=1, num_clips=8, type='SampleFrames'),
    dict(type='RawFrameDecode'),
    dict(scale=(
        -1,
        256,
    ), type='Resize'),
    dict(type='RandomResizedCrop'),
    dict(keep_ratio=False, scale=(
        224,
        224,
    ), type='Resize'),
    dict(flip_ratio=0.5, type='Flip'),
    dict(
        mean=[
            123.675,
            116.28,
            103.53,
        ],
        std=[
            58.395,
            57.12,
            57.375,
        ],
        to_bgr=False,
        type='Normalize'),
    dict(input_format='NCHW', type='FormatShape'),
    dict(
        keys=[
            'imgs',
            'label',
            'metadata',
            'keypoints',
        ],
        meta_keys=[],
        type='Collect'),
    dict(keys=[
        'imgs',
        'label',
        'metadata',
        'keypoints',
    ], type='ToTensor'),
]
val_cfg = dict(type='ValLoop')
val_dataloader = dict(
    batch_size=8,
    dataset=dict(
        ann_file='G:/workspace/test/mmaction2_data/annotations/cat_pose.txt',
        data_prefix=dict(img='G:/workspace/test/mmaction2_data/rawframes'),
        pipeline=[
            dict(
                clip_len=1,
                frame_interval=1,
                num_clips=8,
                test_mode=True,
                type='SampleFrames'),
            dict(type='RawFrameDecode'),
            dict(scale=(
                -1,
                256,
            ), type='Resize'),
            dict(crop_size=224, type='CenterCrop'),
            dict(flip_ratio=0, type='Flip'),
            dict(
                mean=[
                    123.675,
                    116.28,
                    103.53,
                ],
                std=[
                    58.395,
                    57.12,
                    57.375,
                ],
                to_bgr=False,
                type='Normalize'),
            dict(input_format='NCHW', type='FormatShape'),
            dict(
                keys=[
                    'imgs',
                    'label',
                    'metadata',
                    'keypoints',
                ],
                meta_keys=[],
                type='Collect'),
            dict(keys=[
                'imgs',
                'metadata',
                'keypoints',
            ], type='ToTensor'),
        ],
        type='CatPoseDataset'),
    num_workers=2,
    persistent_workers=True,
    sampler=dict(shuffle=False, type='DefaultSampler'))
val_evaluator = dict(type='AccMetric')
val_pipeline = [
    dict(
        clip_len=1,
        frame_interval=1,
        num_clips=8,
        test_mode=True,
        type='SampleFrames'),
    dict(type='RawFrameDecode'),
    dict(scale=(
        -1,
        256,
    ), type='Resize'),
    dict(crop_size=224, type='CenterCrop'),
    dict(flip_ratio=0, type='Flip'),
    dict(
        mean=[
            123.675,
            116.28,
            103.53,
        ],
        std=[
            58.395,
            57.12,
            57.375,
        ],
        to_bgr=False,
        type='Normalize'),
    dict(input_format='NCHW', type='FormatShape'),
    dict(
        keys=[
            'imgs',
            'label',
            'metadata',
            'keypoints',
        ],
        meta_keys=[],
        type='Collect'),
    dict(keys=[
        'imgs',
        'metadata',
        'keypoints',
    ], type='ToTensor'),
]
work_dir = './work_dirs\\cat_pose_recognition'
