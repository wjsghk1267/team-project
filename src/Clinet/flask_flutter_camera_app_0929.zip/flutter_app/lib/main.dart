import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'dart:io';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: CameraUploadPage(),
    );
  }
}

class CameraUploadPage extends StatefulWidget {
  @override
  _CameraUploadPageState createState() => _CameraUploadPageState();
}

class _CameraUploadPageState extends State<CameraUploadPage> {
  final ImagePicker _picker = ImagePicker();

  Future<void> _pickAndUploadImage() async {
    // 이미지 또는 영상 촬영을 위한 카메라 앱 실행
    final XFile? image = await _picker.pickImage(source: ImageSource.camera);
    if (image == null) return; // 사용자가 촬영을 취소한 경우

    // Flask 서버로 파일 업로드
    final uri = Uri.parse('http://192.168.75.190:5000/upload');

    final request = http.MultipartRequest('POST', uri);
    request.files.add(await http.MultipartFile.fromPath('file', image.path));

    try {
      final response = await request.send();
      if (response.statusCode == 200) {
        print('File uploaded successfully');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('File uploaded successfully')),
        );
      } else {
        print('File upload failed');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('File upload failed')),
        );
      }
    } catch (e) {
      print('Error uploading file: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Upload to Flask')),
      body: Center(
        child: ElevatedButton(
          onPressed: _pickAndUploadImage,
          child: Text('Open Camera'),
        ),
      ),
    );
  }
}
