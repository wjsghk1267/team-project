from flask import Flask, request
import os

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024

UPLOAD_FOLDER = './uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# 기본 경로('/')에 대한 엔드포인트 추가
@app.route('/', methods=['GET'])
def home():
    return 'Flask 서버가 정상적으로 실행 중입니다!'

@app.route('/upload', methods=['POST'])
def upload_video():
    if 'video' not in request.files:
        print("No 'video' part in the request.")
        return 'No video part', 400

    file = request.files['video']
    if file.filename == '':
        print("No selected file.")
        return 'No selected file', 400

    file_path = os.path.join(UPLOAD_FOLDER, file.filename)
    try:
        file.save(file_path)
        print(f"File saved to {file_path}")
    except Exception as e:
        print(f"Error saving file: {e}")
        return 'Error saving file', 500

    return 'Video uploaded successfully', 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
