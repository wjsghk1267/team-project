from flask import Flask, request, render_template, send_from_directory
from flask_cors import CORS  # CORS 임포트
import os

app = Flask(__name__)
CORS(app)  # CORS 활성화
UPLOAD_FOLDER = './uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def index():
    try:
        return render_template('index.html')  # templates 폴더에서 index.html을 렌더링
    except Exception as e:
        print(f"Error rendering template: {e}")
        return "An error occurred while rendering the template.", 500

@app.route('/upload', methods=['POST'])
def upload_video():
    if 'video' not in request.files:
        return 'No video part', 400

    file = request.files['video']
    if file.filename == '':
        return 'No selected file', 400

    file_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(file_path)
    return 'Video uploaded successfully', 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, ssl_context=('cert.pem', 'key.pem'))
